<template>
    <v-row>
        <v-col lg="12" class="mt-3 mb-3">
            <h1>Contact</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Duis tristique egestas cursus. Vestibulum aliquam sapien vel quam luctus, sit amet mollis risus aliquam. Proin dignissim justo magna, id rutrum neque cursus sed. Nunc malesuada molestie justo, sed lacinia lorem egestas a. Donec euismod diam non sodales tempus. Vivamus dui neque, aliquam eget imperdiet ac, feugiat eget massa. Mauris sit amet ex eget felis fringilla fringilla. Suspendisse potenti. Nunc blandit scelerisque lacinia. Morbi sed placerat orci, ut malesuada justo. Cras felis dui, cursus sit amet lectus sed, placerat bibendum metus. Proin in iaculis odio, sit amet consectetur arcu. Nunc facilisis nunc at maximus efficitur. Vestibulum bibendum ex sed tellus commodo, in pellentesque odio efficitur. Cras dignissim nisi odio, non rutrum ante rutrum sed.</p>
        </v-col>
    </v-row>
</template>
