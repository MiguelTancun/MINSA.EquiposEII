<template>
    <div class="wrapper" id="app">
        <router-view />
    </div>
</template>
