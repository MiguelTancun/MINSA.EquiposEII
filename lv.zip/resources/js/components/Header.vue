<template>
    <v-app-bar app color="red" dark>
        <v-app-bar-nav-icon @click.stop="$emit('toggle-drawer')"></v-app-bar-nav-icon>
        <v-toolbar-title>Shop</v-toolbar-title>
    </v-app-bar>
</template>
