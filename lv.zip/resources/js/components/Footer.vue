<template>
    <footer class="main-footer text-center">
            <strong
                >Copyright &copy; {{ new Date().getFullYear() }}
                <a href="https://www.minsa.gob.pe"
                    >Ministerio de Salud - DIPOS - DGAIN</a
                >.</strong
            >
            | Todos los derechos reservados.
    </footer>
</template>

<script>
export default {};
</script>
