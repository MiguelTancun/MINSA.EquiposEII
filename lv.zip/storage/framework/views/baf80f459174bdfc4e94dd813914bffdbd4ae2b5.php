<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <meta name="baseUrl" content="<?php echo e(url('')); ?>">
    <title>Ministerio de Salud - DIPOS - DGAIN</title>
    <link rel="shortcut icon" href="images/icon.jpg">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>

<body>

    <div id="app">
    </div>

    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>

</html><?php /**PATH /home/alvi/Projects/miguel/minsa-f/resources/views/application.blade.php ENDPATH**/ ?>