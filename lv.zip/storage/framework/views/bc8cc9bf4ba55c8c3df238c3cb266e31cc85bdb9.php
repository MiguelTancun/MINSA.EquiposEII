<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Homepage</title>

    <link href="<?php echo e(asset(mix('css/app.css'))); ?>" rel="stylesheet">
</head>

<body>

    <div id="app">
        <App />
    </div>

    <script src="<?php echo e(asset(mix('js/app.js'))); ?>"></script>
</body>

</html><?php /**PATH /home/alvi/Projects/miguel/minsa-f/resources/views/welcome.blade.php ENDPATH**/ ?>